<!DOCTYPE html>
<html lang="pt">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Sistema Eleitoral</title>
   <h2><center>Cadastro</h2>
</head>

<body>

   <form method="post" action="insert.php" name="dados" onSubmit="return enviardados();">
    
    

      <table width="588" border="8" align="center">
         <tr>
            <td height="22"></td>
            <td>
               <button class="waves-effect waves-light btn" type="submit" name="action" formaction="select.php">Eleitor</button>
               <button class="waves-effect waves-light btn" type="submit" name="action" formaction="deletar.php">Candidato
               </button>
               <!--<button type='submit' formaction='pegar.php'>Consultar</button>-->
            </td>
         </tr>
      </table>
   </form>
</body>

</html>