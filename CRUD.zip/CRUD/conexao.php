<?php

$servidor = "localhost";
$banco = "id18842430_db_login";
$usuario = "id18842430_root";
$senha = "MZr*0J~yDYnLoarz";
$porta = "3306";

$conexao = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);

if (!$conexao){
    die("A conexão falhou: ". mysqli_connect_error());
}
echo "A conexão foi efetuada com sucesso!";
?>